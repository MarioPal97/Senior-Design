Place this folder in:
/home/pi/.local/lib/python3.7/site-packages/speech_recognition/pocketsphinx-data/